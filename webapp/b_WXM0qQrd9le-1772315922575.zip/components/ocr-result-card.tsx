'use client';

import React from 'react';
import { GlassCard } from '@/components/glass-card';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface OCRResultCardProps {
  text: string;
  confidence: number;
}

export function OCRResultCard({ text, confidence }: OCRResultCardProps) {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <GlassCard className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-lg">Extracted Text</h3>
        <button
          onClick={copyToClipboard}
          className="p-2 hover:bg-muted/50 rounded-lg transition-colors"
          title="Copy to clipboard"
        >
          {copied ? (
            <Check className="w-5 h-5 text-green-500" />
          ) : (
            <Copy className="w-5 h-5 text-primary" />
          )}
        </button>
      </div>

      {/* Confidence Score */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Confidence Score</span>
          <span className="font-bold text-primary">
            {(confidence * 100).toFixed(1)}%
          </span>
        </div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-300"
            style={{ width: `${confidence * 100}%` }}
          />
        </div>
      </div>

      {/* Extracted Text */}
      <div className="bg-background/50 rounded-lg p-4 max-h-64 overflow-y-auto">
        <p className="text-foreground/90 whitespace-pre-wrap text-sm leading-relaxed">
          {text}
        </p>
      </div>

      <p className="text-xs text-muted-foreground">
        {text.split(/\s+/).length} words extracted
      </p>
    </GlassCard>
  );
}
