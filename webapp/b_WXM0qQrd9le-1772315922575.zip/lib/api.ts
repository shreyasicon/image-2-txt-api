// OCR API Integration
const OCR_API_BASE = 'https://xkdvpogqt0.execute-api.us-east-1.amazonaws.com/prod';

export async function extractTextFromImage(imageFile: File): Promise<{
  text: string;
  confidence: number;
  success: boolean;
  error?: string;
}> {
  try {
    const formData = new FormData();
    formData.append('image', imageFile);

    const response = await fetch(`${OCR_API_BASE}/ocr`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`OCR API error: ${response.statusText}`);
    }

    const data = await response.json();
    
    return {
      text: data.text || '',
      confidence: data.confidence || 0.8,
      success: true,
    };
  } catch (error) {
    return {
      text: '',
      confidence: 0,
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
}

// OpenAI API Integration
export async function generateCaptions(
  text: string,
  tone: 'professional' | 'creative' | 'viral' = 'creative'
): Promise<string[]> {
  try {
    const apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OpenAI API key not configured');
    }

    const toneDescriptions: Record<string, string> = {
      professional: 'formal, business-appropriate',
      creative: 'engaging, unique, thought-provoking',
      viral: 'attention-grabbing, shareable, trending',
    };

    const prompt = `Generate 5 high-quality social media captions based on this extracted content: "${text}". 
    Tone: ${toneDescriptions[tone]}.
    Format: Return ONLY the captions, one per line, without numbering or additional text.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    
    // Parse captions from response
    const captions = content
      .split('\n')
      .filter((line: string) => line.trim().length > 0)
      .slice(0, 5);

    return captions;
  } catch (error) {
    console.error('Caption generation error:', error);
    return [];
  }
}

export async function generateTags(text: string): Promise<string[]> {
  try {
    const apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OpenAI API key not configured');
    }

    const prompt = `Generate 15 relevant hashtags for this content: "${text}". 
    Mix SEO-friendly and trending tags.
    Format: Return ONLY hashtags separated by spaces, without explanation.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 300,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    
    // Parse tags - extract hashtags
    const tags = content
      .match(/#\w+/g) || []
      .slice(0, 15);

    return tags;
  } catch (error) {
    console.error('Tag generation error:', error);
    return [];
  }
}

export async function enhanceContent(
  text: string,
  action: 'rewrite-formal' | 'rewrite-viral' | 'summarize' | 'expand' | 'translate'
): Promise<string> {
  try {
    const apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OpenAI API key not configured');
    }

    const prompts: Record<string, string> = {
      'rewrite-formal': `Rewrite this content in a formal, professional tone: "${text}"`,
      'rewrite-viral': `Rewrite this content to be more viral, engaging, and shareable: "${text}"`,
      'summarize': `Summarize this content in 2-3 sentences: "${text}"`,
      'expand': `Expand this content with more details and context: "${text}"`,
      'translate': `Translate this content to professional Spanish: "${text}"`,
    };

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'user',
            content: prompts[action],
          },
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Content enhancement error:', error);
    return '';
  }
}
