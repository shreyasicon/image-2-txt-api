'use client';

import { useState } from 'react';
import Link from 'next/link';
import { UploadCard } from '@/components/upload-card';
import { OCRResultCard } from '@/components/ocr-result-card';
import { GlassCard } from '@/components/glass-card';
import { GlowButton } from '@/components/glow-button';
import { LoadingSpinner } from '@/components/loading-spinner';
import { extractTextFromImage } from '@/lib/api';
import { ArrowRight, AlertCircle } from 'lucide-react';

interface UploadState {
  text: string;
  confidence: number;
  error?: string;
}

export default function UploadPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [ocrResult, setOcrResult] = useState<UploadState | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileSelect = async (file: File) => {
    setSelectedFile(file);
    setOcrResult(null);
    setIsLoading(true);

    try {
      const result = await extractTextFromImage(file);
      
      if (result.success) {
        setOcrResult({
          text: result.text,
          confidence: result.confidence,
        });
      } else {
        setOcrResult({
          text: '',
          confidence: 0,
          error: result.error || 'Failed to extract text',
        });
      }
    } catch (error) {
      setOcrResult({
        text: '',
        confidence: 0,
        error: 'An error occurred during extraction',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setSelectedFile(null);
    setOcrResult(null);
  };

  const isReadyForNextStep = ocrResult && ocrResult.text && !ocrResult.error;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-4xl font-orbitron font-bold">
            Upload & <span className="neon-text">Extract</span>
          </h1>
          <p className="text-muted-foreground text-lg">
            Upload an image and extract text using advanced OCR technology
          </p>
        </div>

        {/* Upload Section */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload Card */}
          <div>
            <UploadCard
              onFileSelect={handleFileSelect}
              isLoading={isLoading}
              selectedFile={selectedFile}
              onClear={handleClear}
            />
          </div>

          {/* OCR Result or Loading */}
          <div>
            {isLoading && (
              <GlassCard className="h-full flex flex-col items-center justify-center min-h-80">
                <div className="space-y-4 text-center">
                  <LoadingSpinner />
                  <p className="text-foreground font-medium">Processing your image...</p>
                  <p className="text-sm text-muted-foreground">
                    This may take a few moments
                  </p>
                </div>
              </GlassCard>
            )}

            {!isLoading && ocrResult && ocrResult.error && (
              <GlassCard className="border-destructive/50 space-y-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
                  <div className="space-y-2">
                    <h3 className="font-bold text-destructive">Error</h3>
                    <p className="text-sm text-muted-foreground">{ocrResult.error}</p>
                  </div>
                </div>
                <button
                  onClick={handleClear}
                  className="text-sm text-primary hover:underline"
                >
                  Try another image
                </button>
              </GlassCard>
            )}

            {!isLoading && ocrResult && !ocrResult.error && (
              <div className="space-y-4">
                <OCRResultCard text={ocrResult.text} confidence={ocrResult.confidence} />
              </div>
            )}
          </div>
        </div>

        {/* Next Steps */}
        {isReadyForNextStep && (
          <GlassCard className="space-y-4">
            <h3 className="font-bold text-lg">What's Next?</h3>
            <p className="text-muted-foreground">
              Great! Your text has been extracted successfully. Now you can:
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <Link href="/dashboard/ai-tools">
                <div className="p-4 rounded-lg border border-primary/30 hover:bg-primary/10 transition-all cursor-pointer group">
                  <h4 className="font-bold group-hover:text-primary transition-colors mb-1">
                    Generate Captions
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Create professional, creative, or viral captions
                  </p>
                </div>
              </Link>
              <Link href="/dashboard/ai-tools">
                <div className="p-4 rounded-lg border border-secondary/30 hover:bg-secondary/10 transition-all cursor-pointer group">
                  <h4 className="font-bold group-hover:text-secondary transition-colors mb-1">
                    Generate Tags
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Get relevant hashtags for your content
                  </p>
                </div>
              </Link>
            </div>
            <div className="pt-4 flex gap-3">
              <Link href="/dashboard/ai-tools" className="flex-1">
                <GlowButton variant="primary" className="w-full">
                  Continue to AI Tools <ArrowRight className="w-4 h-4 ml-2" />
                </GlowButton>
              </Link>
              <button
                onClick={handleClear}
                className="px-4 py-2 rounded-lg border border-border/50 hover:bg-muted/50 transition-colors"
              >
                Upload Another
              </button>
            </div>
          </GlassCard>
        )}

        {/* Info Box */}
        {!selectedFile && (
          <GlassCard className="border-primary/30 space-y-3">
            <h3 className="font-bold">Tips for Best Results</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Use clear, high-contrast images for better accuracy</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Ensure text is straight and not distorted</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Supported formats: JPG, PNG, WebP, GIF</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Maximum file size: 20MB</span>
              </li>
            </ul>
          </GlassCard>
        )}
      </div>
    </div>
  );
}
